var widgetname = document.currentScript.dataset.widgetname;
FigureWidgets.add(widgetname, FigureWidgets.inputTagWidget);
